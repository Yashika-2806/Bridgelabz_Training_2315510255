package Programing_elements.Level_1;

public class quest3 {
    public static void main(String[] args) {
        double kilometers = 10.8;
        double miles = kilometers / 1.6;
        System.out.println("The distance " + kilometers + " km in miles is " + miles);
    }
}
