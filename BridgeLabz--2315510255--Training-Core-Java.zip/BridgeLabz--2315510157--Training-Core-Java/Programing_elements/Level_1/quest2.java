package Programing_elements.Level_1;

public class quest2 {
    public static void main(String[] args) {
        int mathsMark = 94;
        int physicsMark = 95;
        int chemistryMark = 96;
        double averageMark = (mathsMark + physicsMark + chemistryMark) / 3.0;
        System.out.println("Sam's average mark in PCM is " + averageMark);
    }
}
